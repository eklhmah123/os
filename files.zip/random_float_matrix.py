#!/usr/bin/env python3

import random
import sys

def generate_random_matrix(rows, cols, filename):
    try:
        with open(filename, 'w') as f:
            # Write matrix dimensions
            f.write(f"{rows} {cols}\n")
            
            # Write matrix data with proper formatting
            for i in range(rows):
                row = []
                for j in range(cols):
                    # Generate number between 1.0 and 100.0 (avoid leading zeros)
                    num = random.uniform(1.0, 100.0)
                    # Format to 6 decimal places without leading zeros
                    row.append(f"{num:.6f}")
                f.write(" ".join(row) + "\n")
                
        print(f"Generated matrix: {filename} ({rows}x{cols})")
        
    except Exception as e:
        print(f"Error writing to {filename}: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python random_float_matrix.py <size> <output_file_A> <output_file_B>")
        print("Example: python random_float_matrix.py 10 matrix_A.txt matrix_B.txt")
        sys.exit(1)
    
    try:
        size = int(sys.argv[1])
        file_a = sys.argv[2]
        file_b = sys.argv[3]
        
        # Generate two square matrices of the given size
        generate_random_matrix(size, size, file_a)
        generate_random_matrix(size, size, file_b)
        
        print(f"Successfully generated two {size}x{size} matrices")
        
    except ValueError:
        print("Error: Size must be an integer")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
