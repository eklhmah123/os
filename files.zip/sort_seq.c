#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void generate_random_array(int *array, int size) {
    for(int i = 0; i < size; i++) {
        array[i] = rand() % 10000;
    }
}

void bubble_sort(int *array, int size) {
    for(int i = 0; i < size-1; i++) {
        for(int j = 0; j < size-i-1; j++) {
            if(array[j] > array[j+1]) {
                int temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }
}

int main(int argc, char *argv[]) {
    if(argc != 2) {
        printf("Usage: %s <array_size>\n", argv[0]);
        return 1;
    }
    
    int size = atoi(argv[1]);
    int *array = malloc(size * sizeof(int));
    
    srand(time(NULL));
    generate_random_array(array, size);
    bubble_sort(array, size);
    free(array);
    return 0;
}
