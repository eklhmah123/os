#!/bin/bash

echo "🧹 CLEANING UP FOR NEW ASSIGNMENT RUN"
echo "======================================"

cd ~/matrix_multiplication

echo "1. Removing old matrix files..."
rm -f matrix_*.txt test_*.txt manual_*.txt simple_*.txt debug_*.txt tab_*.txt precise_*.txt

echo "2. Removing backup files..."
rm -f src/matrix.c.backup *.backup

echo "3. Removing old result files..."
rm -f results.csv assignment_results.csv realistic_results.csv complete_results.csv

echo "4. Cleaning compiled programs..."
make clean

echo "5. Checking disk space..."
df -h .

echo ""
echo "✅ CLEANUP COMPLETE!"
echo "===================="
ls -la *.txt 2>/dev/null || echo "No text files remaining"
ls -la bin/ 2>/dev/null || echo "bin directory is empty"
