#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

typedef struct {
    int *array;
    int size;
    int thread_id;
    int num_threads;
} thread_data_t;

void generate_random_array(int *array, int size) {
    for(int i = 0; i < size; i++) {
        array[i] = rand() % 10000;
    }
}

void* bubble_sort_parallel(void* arg) {
    thread_data_t* data = (thread_data_t*) arg;
    int *array = data->array;
    int size = data->size;
    int thread_id = data->thread_id;
    int num_threads = data->num_threads;
    
    int chunk_size = size / num_threads;
    int start = thread_id * chunk_size;
    int end = (thread_id == num_threads - 1) ? size - 1 : (thread_id + 1) * chunk_size - 1;
    
    // Perform bubble sort on local chunk
    for(int i = start; i < end; i++) {
        for(int j = start; j < end - (i - start); j++) {
            if(array[j] > array[j+1]) {
                int temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }
    
    return NULL;
}

void merge_sorted_chunks(int *array, int size, int num_chunks) {
    // Simple merge - in practice you'd want a proper merge algorithm
    for(int i = 0; i < size-1; i++) {
        for(int j = 0; j < size-i-1; j++) {
            if(array[j] > array[j+1]) {
                int temp = array[j];
                array[j] = array[j+1];
                array[j+1] = temp;
            }
        }
    }
}

int main(int argc, char *argv[]) {
    if(argc != 3) {
        printf("Usage: %s <array_size> <num_threads>\n", argv[0]);
        return 1;
    }
    
    int size = atoi(argv[1]);
    int num_threads = atoi(argv[2]);
    int *array = malloc(size * sizeof(int));
    
    srand(time(NULL));
    generate_random_array(array, size);
    
    pthread_t threads[num_threads];
    thread_data_t thread_data[num_threads];
    
    // Create threads
    for(int i = 0; i < num_threads; i++) {
        thread_data[i].array = array;
        thread_data[i].size = size;
        thread_data[i].thread_id = i;
        thread_data[i].num_threads = num_threads;
        pthread_create(&threads[i], NULL, bubble_sort_parallel, &thread_data[i]);
    }
    
    // Join threads
    for(int i = 0; i < num_threads; i++) {
        pthread_join(threads[i], NULL);
    }
    
    // Merge the sorted chunks
    merge_sorted_chunks(array, size, num_threads);
    
    free(array);
    return 0;
}
