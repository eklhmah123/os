#!/bin/bash
sizes=(1000 5000 10000 50000)
echo "Array Size, Sequential, OpenMP, Pthreads" > sorting_results.csv
for size in "${sizes[@]}"; do
    echo "Testing array size: $size"
    echo -n "$size, " >> sorting_results.csv
    seq_time=$( { time ./bin/sort_seq $size > /dev/null; } 2>&1 | grep real | awk '{print $2}' | sed 's/m//' | sed 's/s//' )
    echo -n "$seq_time, " >> sorting_results.csv
    omp_time=$( { time OMP_NUM_THREADS=2 ./bin/sort_omp $size > /dev/null; } 2>&1 | grep real | awk '{print $2}' | sed 's/m//' | sed 's/s//' )
    echo -n "$omp_time, " >> sorting_results.csv
    pthread_time=$( { time ./bin/sort_pthread $size 2 > /dev/null; } 2>&1 | grep real | awk '{print $2}' | sed 's/m//' | sed 's/s//' )
    echo "$pthread_time" >> sorting_results.csv
done
echo "Sorting benchmark complete"
cat sorting_results.csv
